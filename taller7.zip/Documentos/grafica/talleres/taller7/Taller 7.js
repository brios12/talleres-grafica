kaboom({
    //Se puede parametrizar el tamaño de la interfaz con width y height
    //width: 320,
    //heisht: 240,
    global: true,
    fullscreen: true,
    scale: 0.9,
    clearColor: [0.1, 0.3, 0.5, 0.5],
})
loadRoot('https://i.imgur.com/')
loadSprite('bloque', 'pogC9x5.png')
loadSprite('Mario', 'Wb1qfhK.png')
loadSprite('nube', 'HajpuN6.png')
loadSprite('enemigo', 'KPO3fR9.png')
loadSprite('tubsup', 'rl3cTER.png')
loadSprite('tubizq', 'c1cYSbt.png')
loadSprite('tubder', 'nqQ79eI.png')
loadSprite('bloqpr', 'gesQ1KP.png')
loadSprite('mont', 'zczJDY9.png')
loadSprite('arbusto', 'bfFRiKY.png')
loadSprite('bloque1', 'bdrLpi6.png')
loadSprite('bloque2', '3e5YRQd.png')
loadSprite('hongo', '0wMd92p.png')


scene("juego", () => {
    layers(['bg', 'obj', 'ui'], 'obj')
    const map = [
        '                                                ',
        '  /           /            /         /          ',
        '                                                ',
        '         /          /                           ',
        '                                                ',
        '                                                ',
        '                                                ',
        '                                                ',
        '                                                ',
        '                                                ',
        '                                                ',
        '              +===&==            $              ',
        '      -                                         ',
        '    ;    ;        % h _           ¿;            ',
        '==========================   =================  ',
        'jjjjjjjjjjjjjjjjjjjjjjjjj    jjjjjjjjjjjjjjjj   ',
        ',,,,,,,,,,,,,,,,,,,,,,,,,,    ,,,,,,,,,,,,,,,,,,',
        '] ] ] ] ] ] ] ] ] # # # [     [ # # # # ] ] ] ]',
    ]
    const levelCfg = {
        width: 20,
        height: 20,
        '=': [sprite('bloque'), solid()],
        '%': [sprite('Mario'), solid()],
        '/': [sprite('nube'), solid()],
        '¿': [sprite('enemigo'), solid()],
        '-': [sprite('tubsup'), solid()],
        '.': [sprite('tubizq'), solid()],
        ':': [sprite('tubder'), solid()],
        '+': [sprite('bloqpr'), solid()],
        '_': [sprite('mont'), solid()],
        ';': [sprite('arbusto'), solid()],
        '&': [sprite('bloque1'), solid()],
        'j': [sprite('bloque2'), solid()],
        'h': [sprite('hongo'), solid()]
    }
    const gameLevel = addLevel(map, levelCfg)
})
start("juego")