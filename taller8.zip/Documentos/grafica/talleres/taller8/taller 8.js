kaboom({
    //Se puede parametrizar el tamaño de la interfaz con width y height
    //width: 320,
    //heisht: 240,
    global: true,
    fullscreen: true,
    scale: 1.0,
    debug: true,
    clearColor: [0.1, 0.3, 0.5, 0.5],
})
loadRoot('https://i.imgur.com/')
loadSprite('bloque', 'pogC9x5.png')
loadSprite('Marioizq', '3jaK18V.png')
loadSprite('bloque2', 'fVscIbn.png')
loadSprite('bloque3', 'M6rwarW.png')
loadSprite('Mario', 'Wb1qfhK.png')
loadSprite('nube', 'HajpuN6.png')
loadSprite('enemigo1', 'KPO3fR9.png')
loadSprite('enemigo2', 'LmseqUG.png')
loadSprite('enemigo3', 'SvV4ueD.png')
loadSprite('tubsup', 'rl3cTER.png')
loadSprite('tubizq', 'c1cYSbt.png')
loadSprite('tubder', 'nqQ79eI.png')
loadSprite('bloqpr', 'gesQ1KP.png')
loadSprite('bloqpr2', 'RMqCc1G.png')
loadSprite('mont', 'zczJDY9.png')
loadSprite('arbusto', 'bfFRiKY.png')
loadSprite('moneda', 'wbKxhcd.png')
loadSprite('florecita', 'uaUm9sN.png')
loadSprite('hongo', '0wMd92p.png')
loadSprite('cuadro', 'bdrLpi6.png')
loadSprite('bloque4', '3e5YRQd.png')
loadSprite('bloque5', 'gqVoI2b.png')

scene("juego", () => {
    layers(['bg', 'obj', 'ui'], 'obj')
    const map = [
        '                                                ',
        '  /           /            /         /          ',
        '                                                ',
        '         /          /                        /  ',
        '                             /        /         ',
        '             /                                  ',
        '                                                ',
        '                                                ',
        '                                                ',
        '              (   l                             ',
        '              +===$==                           ',
        '                                                ',
        '      -                                    -    ',
        '    ;    ;                      _                ',
        '==========================   ==================  ',
        
    ]
    const levelCfg = {
        width: 20,
        height: 20,
        '=': [sprite('bloque'), solid()],
        '~': [sprite('Marioizq'), solid()],
        'j': [sprite('bloque2'), solid()],
        ',': [sprite('bloque3'), solid()],
        '%': [sprite('Mario'), solid()],
        '/': [sprite('nube'), solid()],
        '¿': [sprite('enemigo1'), solid()],
        '?': [sprite('enemigo2'), solid()],
        'h': [sprite('enemigo3'), solid()],
        '-': [sprite('tubsup'), solid()],
        '.': [sprite('tubizq'), solid()],
        ':': [sprite('tubder'), solid()],
        '+': [sprite('bloqpr'), solid()],
        '*': [sprite('bloqpr2'), solid()],
        '_': [sprite('mont'), solid()],
        ';': [sprite('arbusto'), solid()],
        '(': [sprite('moneda'), solid()],
        'l': [sprite('florecita'), solid()],
        '&': [sprite('hongo'), solid()],
        '$': [sprite('cuadro'), solid()],
        'm': [sprite('bloque4'), solid()],
        'n': [sprite('bloque5'), solid()],
    }
    const gameLevel = addLevel(map, levelCfg)
        
    const Mario = add([
        sprite('Mario'),
        pos(90, 0),
        scale(1.5),

        body(), 
    ])

    const enemigo1 = add([
        sprite('enemigo1'),
        pos(300, 0),
        scale(1.0),
        body(),
        "enemigo1",
        {
            dir: -1 
        }
    ])
    const enemigo2 = add([
        sprite('enemigo1'),
        pos(800, 0),
        scale(1.0),
        body(),
        "enemigo2",
        {
            dir: -1 
        }
    ])
    const enemigo3 = add([
        sprite('enemigo3'),
        pos(600, 500),
        scale(0.5),
        body(),
        "enemigo3",
        {
            dir: -1 
        }
    ])

    keyDown("right", () => {
        Mario.changeSprite("Mario")
        Mario.move(300, 0)
    })
    keyDown("left", () => {
        Mario.changeSprite("Marioizq")
        Mario.move(-300, 0)
    })

    keyPress("up", () => {
        if (Mario.grounded())
            Mario.jump(500)
    })

    Mario.action(() => {
        camPos(Mario.pos) 
    })
    const vel = 100

    action("enemigo1", (e) => {
        e.move(e.dir * vel, 0)
        if (e.dir > 0)
            enemigo1.changeSprite("enemigo2")
        else
            enemigo1.changeSprite("enemigo1")
        loop(2, () => {
            e.dir = -e.dir
        })
    })

    action("enemigo2", (i) => {
        if (enemigo2.grounded() && i.dir < 0)
            enemigo2.jump(500)
        i.move(i.dir * vel, 0)
        if (i.dir > 0)
            enemigo2.changeSprite("enemigo1")
        else
            enemigo2.changeSprite("enemigo2")
        loop(1, () => {
            i.dir = -i.dir
        })
    })
    action("enemigo3", (e) => {
        e.move(e.dir * vel, 0)
        if (e.dir > 0)
            enemigo1.changeSprite("enemigo2")
        else
            enemigo1.changeSprite("enemigo1")
        loop(3, () => {
            e.dir = -e.dir
        })
    })
})
start("juego")